(function (App) {
	'use strict';
	App.start();
})(window.App);
